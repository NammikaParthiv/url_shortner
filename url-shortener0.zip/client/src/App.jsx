
import {useState} from "react";
import axios from "axios";
export default function App(){
 const [url,setUrl]=useState("");
 const [s,setS]=useState("");
 return(<div>
  <input onChange={e=>setUrl(e.target.value)}/>
  <button onClick={async()=>{const r=await axios.post("http://localhost:1234/",{url});setS(r.data.shortUrl);}}>Go</button>
  <a href={s}>{s}</a>
 </div>)
}
