
const mongoose=require("mongoose");
const urlSchema=new mongoose.Schema({
 shortId:{type:String,unique:true},
 redirectURL:String,
 visitHistory:[{timestamp:Number}]
});
module.exports=mongoose.model("URL",urlSchema);
