
const shortid=require("shortid");
const URL=require("../models/url");
exports.create=async(req,res)=>{
 const {url}=req.body;
 const shortId=shortid.generate();
 await URL.create({shortId,redirectURL:url,visitHistory:[]});
 res.json({shortUrl:`http://localhost:1234/${shortId}`});
}
exports.redirect=async(req,res)=>{
 const e=await URL.findOneAndUpdate({shortId:req.params.id},{$push:{visitHistory:{timestamp:Date.now()}}});
 res.redirect(e.redirectURL);
}
