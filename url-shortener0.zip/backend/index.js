
const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");
const urlRoute=require("./routes/url");
const app=express();
app.use(cors());
app.use(express.json());
mongoose.connect("mongodb://127.0.0.1:27017/urlshort");
app.use("/",urlRoute);
app.listen(1234,()=>console.log("Server running"));
