
const r=require("express").Router();
const c=require("../controllers/url");
r.post("/",c.create);
r.get("/:id",c.redirect);
module.exports=r;
